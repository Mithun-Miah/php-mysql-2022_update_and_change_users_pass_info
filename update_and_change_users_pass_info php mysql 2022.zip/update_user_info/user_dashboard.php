<?php
session_start();
$msg = "";
if($_SESSION['email']==true){
    // echo "<h5>Welcome : $_SESSION[email] </h5>";
    $msg = "$_SESSION[email]";
}else{
    header("location:log.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="user_dashboard.css">
    <title>User Dashboard</title>
</head>
<body>

    <div class="container">
    <a href="logout.php"><button>Logout</button></a>
        <h2 class="title1">Dashboard</h2>
        <br>
        <div class="buttonDiv">
            <h2>Welcome To : <?php echo $msg ?> </h2>
        </div>
        <div class="work_btn">
            <a href="view_info.php"><button>View Profile</button></a>
            <a href="update_profile.php"><button>Update</button></a>
            <a href="change_pass.php"><button>Change Password</button></a>
        </div>
        <div class="user_activity">
            #  Current Date -  <?php echo date("d/m/Y"); ?>
            <br><br>
            #  Version - 0.0.1
            <br><br>
            #  Version Update Date - Sunday, April 10, 2022
            <br><br>
            #  Logged Smart ERP User - 15
        </div>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>