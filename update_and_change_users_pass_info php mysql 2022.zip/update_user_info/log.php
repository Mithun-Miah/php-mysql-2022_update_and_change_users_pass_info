<?php
session_start();

$connect = mysqli_connect('localhost', 'root','','update_db');
if($connect){
  //echo "Conn Success";
}else{
  echo "Conn Unsuccess";
}

$msg ="";

if(isset($_POST['log_btn'])){
  $email = $_POST['email'];
  $password = $_POST['password'];

  $query = "select * from user_info where email='$email' and password='$password'";

  $query_run = mysqli_query($connect,$query);
  $num_rows=mysqli_num_rows($query_run);
  $row = mysqli_fetch_array($query_run);
  $_SESSION["id"]=$row['id'];

  if($num_rows>0){
    $msg = "Login Success";
    header("location: user_dashboard.php");
    $_SESSION['email'] = $row['email'];
  }else{
    $msg = "Email and Password Not Match !";
  }

  // if($email == '' || $password == ''){
  //   echo "<script>alert('Email and Password Not Match !')</script>";
  // }else{

  // }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="log.css">
    <title>Login Window</title>

    <style>
      #regBtn{
        border: none;
        background-color: blue;
        text-decoration:none;
        color: white;
        padding: 15px;
        font-weight: 800;
        border-radius: 10px;
        margin: auto;
        display: block;
        transition: 0.2s step-end;
        cursor: pointer;
      }
      #regBtn:hover{
          background-color: yellowgreen;
          color: white;
      }
    </style>
</head>
<body>

    <div class="container">
        <h2 class="title1">Login Form</h2>
        <p style="color:yellow;"><?php echo $msg ?></p>
        <br>
        <form method="post">
            <div class="mb-3" id="fieldDiv">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <br>
            <div class="mb-3" id="fieldDiv">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" name="password" class="form-control" id="exampleInputPassword1">
            </div>
            <br>

            <br>
            <button type="submit" name="log_btn" id="logBtn" class="btn btn-primary">Login</button>
          </form>
          <div>
            <a href="reg.php"><button type="submit" id="regBtn" class="btn btn-primary">Registration</button></a>
          </div>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>