<?php
session_start();
// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "update_db");

 $id=$_SESSION['id'];
 //For Show Data in Edit page input field
 $read = "SELECT * FROM user_info where id='$id'";
 $query = mysqli_query($connect, $read);
 $row = mysqli_fetch_array($query);

 if(isset($_POST['update_btn'])){
        $full_name = $_POST['full_name'];
        $f_name = $_POST['f_name'];
        $m_name = $_POST['m_name'];
        $email = $_POST['email'];

        $updateinfo = "UPDATE user_info SET 
        full_name = '$full_name', f_name = '$f_name', m_name = '$m_name', email = '$email' WHERE id = $id ";

        $query = mysqli_query($connect, $updateinfo);

        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
 }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="reg.css">
    <title>User Update Window</title>
</head>
<body>

    <div class="container">
    <a href="logout.php"><button>Logout</button></a>
        <h2 class="title1">Update Profile</h2>
        <br>
        <form method="post">
            <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Full Name</label>
                <input type="text" name="full_name" value="<?php echo $row['full_name']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
              <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Father's Name</label>
                <input type="text" name="f_name" value="<?php echo $row['f_name']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
              <div class="mb-3" id="fieldDiv">
                <label for="exampleInputEmail1" class="form-label">Mother's Name</label>
                <input type="text" name="m_name" value="<?php echo $row['m_name']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
              </div>
              <br>
            <div class="mb-3" id="fieldDiv">
              <label for="exampleInputEmail1" class="form-label">Email address</label>
              <input type="email" name="email" value="<?php echo $row['email']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <br>

            <button type="submit" name="update_btn" id="regBtn" class="btn btn-primary">Update</button>
			<br>
            <a href="user_dashboard.php">Back</a>
          </form>
    </div>
    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>